import numpy as np
import pandas as pd
from coordTransform_utils import *


vertices = np.loadtxt('jingyuxian_2021_vertices.txt', delimiter=',')
edges = np.loadtxt('jingyuxian_2021_edges.txt', delimiter=',')

print(edges.shape)

point_list = []
for i in range(edges.shape[0]):
    first_idx, second_idx = int(edges[i,1]), int(edges[i,2])
    lng_first_wgs, lat_first_wgs = vertices[first_idx-1,1],vertices[first_idx-1,2]
    lng_second_wgs, lat_second_wgs = vertices[second_idx-1,1],vertices[second_idx-1,2]
    lng_first_gcj, lat_first_gcj = wgs84_to_gcj02(lng_first_wgs+ 0.0002705-0.000063, lat_first_wgs+0.00073525+0.0003)
    lng_second_gcj, lat_second_gcj = wgs84_to_gcj02(lng_second_wgs+ 0.0002705-0.000063, lat_second_wgs+0.00073525+0.0003)
    point_list.append([[lng_first_gcj, lat_first_gcj],[lng_second_gcj, lat_second_gcj]])

# print(point_list)

with open('point_list.txt', 'w') as f:
    for inner_list in point_list:
        f.write("[")
        for i, sub_list in enumerate(inner_list):
            line = '[' + ', '.join(map(str, sub_list)) + ']'
            f.write(line)
            if i < len(inner_list) - 1:
                f.write(", ")  # 添加逗号分隔不同的内部列表
        f.write("],\n")

