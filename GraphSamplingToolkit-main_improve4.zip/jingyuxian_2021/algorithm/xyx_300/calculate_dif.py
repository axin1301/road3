import numpy as np

# 创建一个示例的 4x4 的二维数组
arr = np.loadtxt('C:/Users/xyx13/OneDrive - University of Helsinki/RoadNetwork_more/靖宇县坐标尝试2.txt', delimiter=',')

# 将奇数行和偶数行分开
odd_rows = arr[::2]  # 奇数行
even_rows = arr[1::2]  # 偶数行

# 计算差值
diff = odd_rows - even_rows

# 计算每列的平均值
column_means = np.mean(diff, axis=0)

print(column_means)