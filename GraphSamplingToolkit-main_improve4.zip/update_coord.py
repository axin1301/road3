import os
import numpy as np

for xian in ['guanghexian','honghexian','jiangzixian','jingyuxian','liboxian','lingqiuxian','linquanxian','shufuxian','xixiangxian']: #'danfengxian']:#,
    dir_name = xian+'_2021/algorithm/xyx_300/'+xian+'_2021_vertices.txt'
    # 加载文本文件
    file_path = dir_name
    data = np.loadtxt(file_path, delimiter=",")

    # 对第二和第三列进行修改
    data[:, 1] = data[:,1] + 0.0002705 - 0.000063  # 对第二列加 0.1
    data[:, 2] = data[:,2] + 0.00073525 + 0.0003  # 对第三列减 0.1

    # 保存修改后的数据到新的文本文件
    output_file_path = xian+'_2021/algorithm/xyx_300/'+xian+'_2021_vertices.txt'
    np.savetxt(output_file_path, data, delimiter=",", fmt=["%d", "%.10f", "%.10f"])

    print("Modified file saved successfully.")